Phase 13 deepens the Apple-native athlete/team rebuild.

Added depth:
- readiness detail sheet
- exercise detail sheet
- richer progress screen with timeline, PRs, and insights
- microcycle preview on Today
- workout recovery cues
- stronger athlete profile and recovery notes
- team layer still inherits the same calm visual system

Full replacement files included:
- index.html
- styles.css
- all files in /js
