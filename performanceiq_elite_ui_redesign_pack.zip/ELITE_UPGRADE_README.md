PerformanceIQ Elite UI Redesign Pack

Included updates:
- redesigned dashboard with premium command-center layout
- upgraded Train, Wellness, Nutrition, Team, Insights, and Settings views
- onboarding left unchanged
- eliteTraining.css expanded with redesign layer
- core.js updated to render the redesigned views and wire interactions

Files to replace:
- index.html
- core.js
- eliteTraining.css

Keep existing onboarding.js and onboarding.css unchanged.
